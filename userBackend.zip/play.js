{
    "product_name": "product22",
    "product_sku": "sku",
    "product_style": "All Styles",
    "product_shipping_details": "details",
    "product_occasion": "Party Wear",
    "product_Fabric": "All Fabrics",
    "product_highlight": [],
    "product_size": "L",
    "product_discount": 0,
    "product_color": "Blue",
    "product_price": 200,
    "product_img": "https://siddhisaree.s3.ap-south-1.amazonaws.com/photo-1572470176170-98fa8abcb741.webp",
    "_id": "64ddb3d0bafcfc5f7c4ee8bf",
    "multi_img": [
        "https://siddhisaree.s3.ap-south-1.amazonaws.com/WhatsApp%20Image%202023-10-07%20at%2010.16.46%20AM.jpeg",
        "https://siddhisaree.s3.ap-south-1.amazonaws.com/WhatsApp%20Image%202023-10-07%20at%2010.16.47%20AM%20-%20Copy.jpeg"
    ]
}